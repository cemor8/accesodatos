public class GeneradorNumerosAleatorios {

    public GeneradorNumerosAleatorios() {
    }
    public Integer generar(){
        return (int) (Math.random()*49)+1;

    }
}
