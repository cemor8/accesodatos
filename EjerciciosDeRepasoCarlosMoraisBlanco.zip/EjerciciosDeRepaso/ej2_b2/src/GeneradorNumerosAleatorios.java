public class GeneradorNumerosAleatorios {
    public GeneradorNumerosAleatorios() {
    }
    public double generar(){
        double numeroAleatorio = Math.random();
        return numeroAleatorio;

    }
}
