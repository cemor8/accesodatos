public class Heroe extends Combatiente{
    public Heroe(double vida, double poder_escudo) {
        super(vida, poder_escudo);
    }
}
